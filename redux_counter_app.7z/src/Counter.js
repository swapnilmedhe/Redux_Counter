
import React from 'react';
import {connect} from 'react-redux';

function Counter(props) {
    return (
        <div>
            <h3>Hey !! its counter component !!</h3>
             
            <p>Count :{props.count}</p>
            <button onClick={props.onIncrement}> Increment </button> <hr></hr>
            <button onClick={props.onDecrement}> Decrement </button> <hr></hr>
        </div>
    )
}



function mapStateToProps(state)
{
    console.log(state.count);

   return {
       count :state.count
   }
}


function mapDispachToprops(dispach){
  return {
    onIncrement : () =>{
        console.log("Incremnet button click");
        const action={
            type:"INCREMENT"
        }

        dispach(action);
    },
    onDecrement : () =>{
        console.log("decrement button click");
        const action={
            type:"DECREMENT"
        }

        dispach(action);
    }
    



  }
}



export default connect(mapStateToProps,mapDispachToprops)(Counter)
